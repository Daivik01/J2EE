import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLOutput;

public class Start {
    public static void main(String[] args) throws IOException {
        System.out.println("Welcome to Student Management App");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        while (true){
            System.out.println("Press 1 to add student");
            System.out.println("Press 2 to delete student");
            System.out.println("Press 3 to display student");
            System.out.println("Press 4 to exit");
            int c =Integer.parseInt(br.readLine());
            if(c==1){
                System.out.println("Enter user name");
                String name = br.readLine();
                System.out.println("Enter user Mobile number");
                String phone = br.readLine();
                System.out.println("Enter city name");
                String city = br.readLine();

                //Creating student object to store object
                Student st = new Student(name,phone,city);
                boolean answer=StudentDao.insertStudentToDB(st);
                if(answer){
                    System.out.println("Student is added Successfully");
                }
                else {
                    System.out.println("Something went wrong");
                }
                System.out.println(st);


            }
            else if(c==2){
                System.out.println("Enter student Id to delete: ");
                int userId = Integer.parseInt(br.readLine());
                StudentDao.deleteStudent(userId);
                boolean f = StudentDao.deleteStudent(userId);
                if(f){
                    System.out.println("Deleted");
                }
                else {
                    System.out.println("Something went wrong");
                }
            }
            else if(c==3){
                StudentDao.showAll();

            }
            else if(c==4) {
            System.out.println("Thank you");
                break;
            }
            else {
            }
        }
    }
}
