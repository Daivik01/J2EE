package com.example.servlettry;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet(name = "Registration", value = "/Registration")
public class Registration extends HttpServlet {
   static boolean b= true;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String passwordd = request.getParameter("password");
        String LastName = request.getParameter("LastName");
        String FirstName = request.getParameter("FirstName");

        if(userId!=null && passwordd!=null && LastName!=null && FirstName!=null){
            getConnection();
        }
        else {
            response.sendRedirect("NewUser.jsp");
            boolean b= false;
        }
    }
    public  static boolean check(){
        return b;
    }
    public static Connection getConnection(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String user = "root";
            String password ="daivik";
            String url ="jdbc://localhost:3306/Registration";
            Connection con = DriverManager.getConnection(url,user,password);
            return con;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
