package com.example.daivik_crud;

import java.sql.Connection;
import java.sql.DriverManager;

public class CG {
    static Connection con ;
    public static Connection createc(){
        //Load driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //create the connection...
            String user = "root";
            String password ="daivik";
            String url = "jdbc:mysql://localhost:3306/user_registration";
            con  = DriverManager.getConnection(url,user,password);
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
}
