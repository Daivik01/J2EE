package com.example.daivik_crud;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UserDao {
    public int registrationDE(UserRegister ur) throws ClassNotFoundException {
        String sql = "INSERT INTO students1 (name,mobileno,city) "+"values (?,?,?);";
        int result = 0;
       try{

             PreparedStatement prst = CG.createc().prepareStatement(sql);

                prst.setString(1, ur.getFirstname());
               prst.setString(2, ur.getMobileno());
               prst.setString(3, ur.getCity());
               System.out.println(prst);
               result = prst.executeUpdate();
           }
           catch(Exception e){
               System.out.println(e);
           }
        return result;
    }
}
