	package net.javaguides.registration.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import net.javaguides.registration.model.Employee;

public class EmployeeDao {
	
	public int registerEmployee(Employee employee) throws ClassNotFoundException{
		
		String INsert = "INSERT INTO empolyee "+" (first_name,last_name,username,password,address,contact) VALUES "+" (?,?,?,?,?,?)";
		String Delete = "DELETE FROM empolyee WHERE id=1; ";
		int result = 0;
		Class.forName("com.mysql.jdbc.Driver");
		
		try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo1","root","daivik")){
				PreparedStatement prst = connection.prepareStatement(INsert);
				PreparedStatement prst1= connection.prepareStatement(Delete);
				
				prst.setString(1,employee.getFirstname());
				prst.setString(2,employee.getLastname());
				prst.setString(3,employee.getUsername());
				prst.setString(4,employee.getPassword());
				prst.setString(5,employee.getAddress());
				prst.setString(6,employee.getContact());
				
				System.out.println(prst);
				result = prst.executeUpdate();
			int	result1 = prst1.executeUpdate();
			System.out.println(result1);
				
		}catch(Exception e){
			System.out.println(e);
		}
		
		return result;
		
	}

}
