package com.xadmin.usermanagement.dao;

import com.xadmin.usermanagement.bean.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserDao {
        private String jdbcUrl = "jdbc:mysql://localhost:3306/userdb?useSSL=false";
        private String user =  "root";
        private String password="daivik";
        private String jdbcDriver ="com.mysql.jdbc.Driver";

        private static final  String sql= "INSERT INTO users" + " (name,email,country) values "+ " (?, ?, ?); ";
        private static final String Select_user = "select name,email,country from users where name =?";
        private static final String Select_all = "select * from users";
        private static final String Delete = "delete from users where name = ?";
        private static final String update = "update users set email=?,country=? where name = ?;";

        public UserDao() {
        }
        protected Connection getConnection(){
                Connection conn = null;
                try {
                        Class.forName("jdbcDriver");
                        conn = DriverManager.getConnection(jdbcUrl,user,password);

                } catch (Exception e) {
                        e.printStackTrace();
                }
                return conn;
        }
        public void insertUser(User user){
                System.out.println(sql);
                try(Connection conn = getConnection();
                    PreparedStatement prt= conn.prepareStatement(sql)
                ) {
                        prt.setString(1,user.getName());
                        prt.setString(2,user.getEmail());
                        prt.setString(3,user.getCountry());
                        System.out.println(prt);
                        prt.executeUpdate();

                } catch (SQLException e) {
                        e.printStackTrace();
                }
        }
}
