package net.javaguides.registration.services;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.javaguides.registration.dao.EmployeeDao;
import net.javaguides.registration.model.Employee;

public class EmployeeServices implements ServicesInterface {
	Employee ep= new Employee();
	@Override
	public void services() {
	}
	public void Services1(String firstname) {
		ep.setFirstname(firstname);
	}
	public void Services2(String lastname) {
		ep.setLastname(lastname);
	}
	public void Services3(String username) {
		ep.setUsername(username);
	}
	public void Services4(String password) {
		ep.setPassword(password);
	}
	public void Services5(String address) {
		ep.setAddress(address);
	}
	public void Services6(String contact) {
		ep.setContact(contact);
	}
	
	public void reciveService(HttpServletRequest requestt,HttpServletResponse response) {
		 EmployeeServices es = new EmployeeServices();
		 es.Services1(requestt.getParameter("firstName"));
		 es.Services2(requestt.getParameter("lastName"));
		 es.Services3(requestt.getParameter("username"));
		 es.Services4(requestt.getParameter("password"));
		 es.Services5(requestt.getParameter("address"));
		 es.Services6(requestt.getParameter("contact"));
		 

		 if(es.dao()) {
		 try {
			requestt.getRequestDispatcher("employeedetails.jsp").include(requestt,response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		 else {
			 try {
				requestt.getRequestDispatcher("employeeregister.jsp").include(requestt,response);
			} catch (ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 
	}
	
	public boolean dao()  {
		EmployeeDao edao = new EmployeeDao();
		try {
			edao.registerEmployee(ep);
			return true;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}


