package com.example.daivik_crud;

public class UserRegister {
    private String firstname ;
//    private String lastname;
    private String mobileno;
    private String city;

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
//
//    public String getLastname() {
//        return lastname;
//    }
//
//    public void setLastname(String lastname) {
//        this.lastname = lastname;
//    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public UserRegister(String firstname, String mobileno, String city) {
        this.firstname = firstname;
//        this.lastname = lastname;
        this.mobileno = mobileno;
        this.city = city;
    }

    public UserRegister() {
    }
}
