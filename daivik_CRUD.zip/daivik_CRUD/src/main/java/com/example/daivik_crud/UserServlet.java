package com.example.daivik_crud;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UserServlet", value = "/UserServlet")
public class UserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstname = request.getParameter("firstname");
//        String mobileno = request.getParameter("mobileno");
        String mobileno1 = request.getParameter("mobileno");
        String city = request.getParameter("city");


        UserRegister ur =new UserRegister();
        ur.setFirstname(firstname);
        ur.setMobileno(mobileno1);

        ur.setCity(city);
        UserDao udao=new UserDao();
        try {
            udao.registrationDE(ur);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        response.sendRedirect("successfulInset.jsp");
    }
}
