package net.javaguides.registration.services;

interface ServicesInterface  {
		public void services();
}
