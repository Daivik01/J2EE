package com.example.servlettry;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "LoginAuthentication", value = "/LoginAuthentication")
public class LoginAuthentication extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");

        if(userId.equals("Daivik") && password.equals("Daivik")){
            response.sendRedirect("Successful.jsp");
        }
        else{
            response.sendRedirect("Unsuccessful.jsp");
        }
    }
}
//referance  https://www.javatpoint.com/HttpServlet-class   https://www.javatpoint.com/life-cycle-of-a-servlet#servletlifecycle3
//for JSP https://javabeginnerstutorial.com/jsp-tutorial/jsp-basics/ https://www.techguruspeaks.com/jsp-tags/
